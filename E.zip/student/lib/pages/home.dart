import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:http/http.dart' as http;

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  bool ser = false;
  Map single = {
    "studid": "1",
    "pass": "AA161270506",
    "fname": "Claudia Hane Sr.",
    "study": "Cambridgeshire",
    "studyear": "2012",
    "isgrant": "grand",
    "born": "2023-09-26T19:24:41.063",
    "bornplace": "Qoraqalpog‘iston Respublikasi",
    "phone": "+998947795149"
  };
  var msea = TextEditingController(text: '');
  var idkart = TextEditingController(text: '');
  var bdate = TextEditingController(text: '');
  var advs = false;
  var phone = TextEditingController(text: '');
  var exp = false;
  Future pol = getEmployeeData();
  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
        future: pol,
        builder: (context, snapshot) {
          return Scaffold(
              appBar: AppBar(
                backgroundColor: Colors.green.shade300,
                title: const Text('Talabalar ro\'yxati'),
                actions: [
                  IconButton(
                      onPressed: () {
                        if (ser) {
                          pol = getEmployeeData();
                        }
                        setState(
                          () {
                            msea.text = '';
                            idkart.text = '';
                            bdate.text = '';
                            phone.text = '';
                            ser = !ser;
                          },
                        );
                      },
                      icon: Icon(!ser ? Icons.search : Icons.search_off)),
                  IconButton(
                      onPressed: () {}, icon: const Icon(Icons.more_vert))
                ],
              ),
              body: SingleChildScrollView(
                  child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Container(
                  //   child: Row(
                  //     children: [
                  //       TextButton(
                  //           onPressed: () {}, child: const Text("Dashboard")),
                  //       TextButton(
                  //           onPressed: () {}, child: const Text("Kunlik")),
                  //       TextButton(
                  //           onPressed: () {}, child: const Text("Dashboard")),
                  //     ],
                  //   ),
                  // ),
                  Container(
                    width: MediaQuery.of(context).size.width,
                    margin: const EdgeInsets.fromLTRB(15, 10, 0, 0),
                    child: Visibility(
                        maintainState: true,
                        maintainAnimation: true,
                        visible: ser,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            SizedBox(
                              height: 50,
                              width: MediaQuery.of(context).size.width / 6,
                              child: SearchBar(
                                leading: IconButton(
                                  icon: SizedBox(
                                    height: 10,
                                    child: Switch(
                                        value: advs,
                                        onChanged: (value) {
                                          setState(() {
                                            advs = value;
                                          });
                                        }),
                                  ),
                                  onPressed: () {},
                                ),
                                controller: msea,
                                onSubmitted: (value) {
                                  if (!advs) {
                                    setState(() {
                                      pol =
                                          getSingleSearch(msea.text.toString());
                                    });
                                    print(value);
                                  }
                                },
                              ),
                            ),
                            const VerticalDivider(),
                            Visibility(
                                visible: advs,
                                child: Row(
                                  children: [
                                    SizedBox(
                                      height: 50,
                                      width:
                                          MediaQuery.of(context).size.width / 5,
                                      child: TextField(
                                        onSubmitted: (value) {
                                          print(value);
                                        },
                                        decoration: const InputDecoration(
                                          focusedBorder: OutlineInputBorder(
                                            borderSide: BorderSide(
                                                color: Colors.greenAccent,
                                                width: 2.0),
                                          ),
                                          enabledBorder: OutlineInputBorder(
                                            borderSide: BorderSide(
                                                color: Colors.grey, width: 2.0),
                                          ),
                                          hintText: 'ID karta', //
                                        ),
                                        controller: idkart,
                                      ),
                                    ),
                                    const VerticalDivider(),
                                    SizedBox(
                                      height: 50,
                                      width:
                                          MediaQuery.of(context).size.width / 5,
                                      child: TextField(
                                        onTap: () async {
                                          await showDatePicker(
                                                  initialDatePickerMode:
                                                      DatePickerMode
                                                          .values.first,
                                                  onDatePickerModeChange:
                                                      (value) {
                                                    print(bdate);
                                                  },
                                                  initialDate: DateTime.now(),
                                                  context: context,
                                                  firstDate: DateTime(1950),
                                                  lastDate: DateTime.now())
                                              .then((onValue) {
                                            setState(() {
                                              bdate.text = onValue
                                                  .toString()
                                                  .split(' ')[0];
                                            });
                                          });
                                        },
                                        onSubmitted: (value) {
                                          print(value);
                                        },
                                        decoration: const InputDecoration(
                                          focusedBorder: OutlineInputBorder(
                                            borderSide: BorderSide(
                                                color: Colors.greenAccent,
                                                width: 2.0),
                                          ),
                                          enabledBorder: OutlineInputBorder(
                                            borderSide: BorderSide(
                                                color: Colors.grey, width: 2.0),
                                          ),
                                          hintText: "Tug'ilgan sanasi", //
                                        ),
                                        controller: bdate,
                                      ),
                                    ),
                                    const VerticalDivider(),
                                    SizedBox(
                                      height: 50,
                                      width:
                                          MediaQuery.of(context).size.width / 5,
                                      child: TextField(
                                        onChanged: (value) {
                                          print(value);
                                        },
                                        onSubmitted: (value) {
                                          print(value);
                                        },
                                        decoration: const InputDecoration(
                                          focusedBorder: OutlineInputBorder(
                                            borderSide: BorderSide(
                                                color: Colors.greenAccent,
                                                width: 2.0),
                                          ),
                                          enabledBorder: OutlineInputBorder(
                                            borderSide: BorderSide(
                                                color: Colors.grey, width: 2.0),
                                          ),
                                          hintText: 'Telefon raqami', //
                                        ),
                                        controller: phone,
                                      ),
                                    ),
                                  ],
                                )),
                            const Spacer(
                              flex: 2,
                            ),
                            ElevatedButton(
                                onPressed: () {
                                  if (msea.text == '' ||
                                      idkart.text == '' ||
                                      bdate == '' ||
                                      phone.text == '') {
                                    ScaffoldMessenger.of(context)
                                        .showSnackBar(const SnackBar(
                                      backgroundColor: Colors.red,
                                      content: Text(
                                          "Barcha kataklarni to'ldirish shart"),
                                    ));
                                  } else {
                                    setState(() {
                                      pol = getMultiSearch([
                                        msea.text,
                                        idkart.text,
                                        bdate.text,
                                        phone.text
                                      ]);
                                    });
                                  }
                                },
                                child: const Text('Qidirish'))
                          ],
                        )),
                  ),
                  snapshot.hasData
                      ? Padding(
                          padding: const EdgeInsets.all(10),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              SizedBox(
                                width: MediaQuery.of(context).size.width * 0.78,
                                child: DataTable(
                                    columnSpacing: 10,
                                    showBottomBorder: true,
                                    horizontalMargin: 5,
                                    border: TableBorder.all(
                                        width: 1, color: Colors.black),
                                    columns: <DataColumn>[
                                      DataColumn(
                                          onSort: (columnIndex, ascending) {},
                                          label: const Text(
                                            'ID raqami',
                                            style: TextStyle(
                                                fontWeight: FontWeight.bold),
                                          )),
                                      const DataColumn(
                                          headingRowAlignment:
                                              MainAxisAlignment.start,
                                          label: Text('ID kartasi',
                                              style: TextStyle(
                                                  fontWeight:
                                                      FontWeight.bold))),
                                      const DataColumn(
                                          label: Text('F.I.O',
                                              style: TextStyle(
                                                  fontWeight:
                                                      FontWeight.bold))),
                                      const DataColumn(
                                          label: Text('O\'qish joyi',
                                              style: TextStyle(
                                                  fontWeight:
                                                      FontWeight.bold))),
                                      const DataColumn(
                                          label: Text('O\'quv yili',
                                              style: TextStyle(
                                                  fontWeight:
                                                      FontWeight.bold))),
                                      const DataColumn(
                                          label: Text('O\'qish shakli',
                                              style: TextStyle(
                                                  fontWeight:
                                                      FontWeight.bold))),
                                      const DataColumn(
                                          label: Text('Tug\'ilgan sana',
                                              style: TextStyle(
                                                  fontWeight:
                                                      FontWeight.bold))),
                                      const DataColumn(
                                          label: Text('Tug\'ilgan joyi',
                                              style: TextStyle(
                                                  fontWeight:
                                                      FontWeight.bold))),
                                      const DataColumn(
                                          label: Text('Telefon',
                                              style: TextStyle(
                                                  fontWeight:
                                                      FontWeight.bold))),
                                    ],
                                    rows: <DataRow>[
                                      ...(snapshot.data as List).map(
                                        (element) => DataRow(cells: [
                                          DataCell(Text(
                                              element['studid'].toString())),
                                          DataCell(Text(element['pass'])),
                                          DataCell(TextButton(
                                              child: Text(element['fname']),
                                              onPressed: () {
                                                setState(() {
                                                  single = element;
                                                });
                                              })),
                                          DataCell(Text(element['study'])),
                                          DataCell(Text(element['studyear'])),
                                          DataCell(Text(element['isgrant'])),
                                          DataCell(Text(DateFormat("yyyy-MM-dd")
                                              .parse(element['born']
                                                  .toString()
                                                  .toString())
                                              .toString())),
                                          DataCell(Text(element['bornplace'])),
                                          DataCell(Text(element['phone'])),
                                        ]),
                                      )
                                    ]),
                              ),
                              Padding(
                                  padding:
                                      const EdgeInsets.fromLTRB(10, 0, 1, 0),
                                  child: Container(
                                    width: MediaQuery.of(context).size.width *
                                        0.20,
                                    height: MediaQuery.of(context).size.height *
                                        0.55,
                                    decoration: BoxDecoration(
                                      border: Border.all(
                                          width: 1, color: Colors.black),
                                    ),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        const Text(
                                          "         Talaba haqida ma'lumot",
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                              fontSize: 25,
                                              fontWeight: FontWeight.bold),
                                        ),
                                        Row(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          children: [
                                            Container(
                                              padding: const EdgeInsets.all(10),
                                              decoration: BoxDecoration(
                                                  border: Border.all(
                                                      width: 1,
                                                      color: Colors.black)),
                                              child: const Icon(
                                                Icons.person_2_outlined,
                                                size: 178,
                                              ),
                                            ),
                                            const VerticalDivider(
                                              width: 5,
                                            ),
                                            Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                const Text(
                                                  "F.I.O.",
                                                  style: TextStyle(
                                                      fontWeight:
                                                          FontWeight.bold),
                                                ),
                                                Text(single['fname']),
                                                const Text(
                                                  "Passport seriya raqami:",
                                                  style: TextStyle(
                                                      fontWeight:
                                                          FontWeight.bold),
                                                ),
                                                Text(single['pass']),
                                                const Text(
                                                  "Talaba IDsi:",
                                                  style: TextStyle(
                                                      fontWeight:
                                                          FontWeight.bold),
                                                ),
                                                Text(single['studid']
                                                    .toString()),
                                                const Text(
                                                  "O'qish joyi",
                                                  style: TextStyle(
                                                      fontWeight:
                                                          FontWeight.bold),
                                                ),
                                                Text(single['study']),
                                                const Text(
                                                  "Telefon raqami",
                                                  style: TextStyle(
                                                      fontWeight:
                                                          FontWeight.bold),
                                                ),
                                                SelectableText(
                                                    single['phone'].toString()),
                                              ],
                                            )
                                          ],
                                        ),
                                        const Text(
                                          "O'qish boshlagan yili",
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold),
                                        ),
                                        Text(single['studyear']),
                                        const Text(
                                          "Ta'lim shakli",
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold),
                                        ),
                                        Text(single['isgrant']),
                                        const Text(
                                          "Tug'ilgan vaqti",
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold),
                                        ),
                                        Text(single['born']),
                                        const Text(
                                          "Tug'ilgan joyi",
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold),
                                        ),
                                        Text(single['bornplace']),
                                        const Text(
                                          "Q'oshimcha ma'lumotlar",
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold),
                                        ),
                                        Container(
                                          margin: const EdgeInsets.all(5),
                                          height: MediaQuery.of(context)
                                                  .size
                                                  .height *
                                              0.1,
                                          decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(15),
                                              border: Border.all(
                                                color: Colors.grey,
                                              )),
                                          child: const Center(
                                            child: Text("ma'lumot topilmadi"),
                                          ),
                                        )
                                      ],
                                    ),
                                  ))
                            ],
                          ))
                      : SizedBox(
                          height: MediaQuery.of(context).size.height * 0.8,
                          child: const Center(
                              child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              CircularProgressIndicator(),
                              Text("Server bilan bog'lanmoqda")
                            ],
                          )),
                        )
                ],
              )));
        });
  }
}

Future getEmployeeData() async {
  Uri uri = Uri.parse('http://127.0.0.1:3000/datatest');
  var resp = await http.get(uri);
  return jsonDecode(resp.body);
}

Future getSingleSearch(String s) async {
  Uri uri = Uri.parse('http://127.0.0.1:3000/api/sfind');

  var resp = await http.post(uri, body: {"fname": s.toString()});
  print(resp.body);
  return jsonDecode(resp.body);
}

Future getMultiSearch(List s) async {
  Uri uri = Uri.parse('http://127.0.0.1:3000/api/mfind');

  var resp = await http.post(uri, body: {
    "fname": s[0].toString(),
    "idkart": s[1].toString(),
    "bdate": s[2].toString(),
    "phone": s[3].toString(),
  });
  print(resp.body);
  return jsonDecode(resp.body);
}

// single['studid']
// single['pass']
// single['fname]
// single['study']

// single['studyear']
// single['isgrant']
// single['born']
// single['bornplace']

// single['phone']
