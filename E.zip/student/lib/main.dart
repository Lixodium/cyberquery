import 'package:flutter/material.dart';
import 'exports.dart';

void main() async {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    theme: ThemeData(),
    darkTheme: ThemeData.dark(),
    themeMode: ThemeMode.dark,
    routes: {
      '/': (context) => const Home(),
    },
  ));
}
