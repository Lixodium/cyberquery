const mysql = require("mysql2");
const { faker } = require('@faker-js/faker');

var connection = mysql.createPool({
  connectionLimit: 5,
  host: "127.0.0.1",
  user: "root",
  password: "",
  database: "talaba",
  multipleStatements: false,
});

// function createRandomUser() {
//   return {
//     userId: faker.string.uuid(),
//     username: faker.person.fullName(),
//     email: faker.internet.email(),
//     avatar: faker.image.avatar(),
//     password: faker.internet.password(),
//     birthdate: faker.date.between({ from: '1998-01-01', to: Date.now() }),
//     registeredAt: faker.helpers.fromRegExp('A{2}') + faker.number.int({ min: 10000000, max: 1000000000 }),
//     phone:faker.phone.number({ style: 'international' }) 
//   };
// }
//console.log(createRandomUser());
// connection.connect((err) => {
  

//   if (!err) console.log("Connection Established Successfully");
//   else console.log("Connection Failed!" + JSON.stringify(err, undefined, 2));
// });
var que = "INSERT INTO `student`(`id`,`studid`,`pass`,`fname`,`study`,`studyear`,`isgrant`,`born`,`born_id`,`phone`) VALUES (?)";
for (let i = 0; i < 90000; i++) {
  des = [null,faker.finance.accountNumber(11),faker.helpers.fromRegExp('A{2}') + faker.number.int({ min: 10000000, max: 1000000000 }),faker.person.fullName(),faker.person.jobTitle(),faker.number.int({ min: 2006, max: 2022 }) ,'grand',faker.date.between({ from: '1998-01-01', to: '2006-01-01' }).toISOString().split('T')[0],faker.number.int({ min: 1, max: 14 }) , faker.phone.number({ style: 'international' }) ];
  connection.query(que,[des], (err, rows) => {

  });

}

console.log("complete");
//connection.end();