const { count } = require("console");
const cors = require("cors");
const bodyParser = require("body-parser");
const express = require("express");
const fs = require("fs");
const mysql = require("mysql");
const { dirname } = require("path");
const app = express();
app.use(
  cors({
    origin: "*",
  })
);
const jsonParser = express.json();
app.use(
  bodyParser.urlencoded({
    extended: true,
  })
);
app.use(bodyParser.json());
//assuming app is express Object.

var connection = mysql.createConnection({
  host: "127.0.0.1",
  user: "root",
  password: "",
  database: "talaba",
  multipleStatements: true,
});

connection.connect((err) => {
  if (!err) console.log("Connection Established Successfully");
  else console.log("Connection Failed!" + JSON.stringify(err, undefined, 2));
});



app.set('view engine','html');
app.use(express.static(__dirname+'/web'));
app.get('/',function (req,res) {
  res.render('index');
  
})



// app.post("/api/tasks", function (req, res) {
//   var cmd = req.body.cmd;
//   var type = req.body.type;
//   var t_id = req.body.cmd_id;

//   if (cmd == "all") {
//     connection.query(
//       "SELECT * FROM `tasks`",
//       (err, rows, fields) => {
//         if (!err) {
//           res.send(rows);
//         } else console.log(err);
//       }
//     );
//   } else if (cmd == "filt" && t_id == 0) {
//     connection.query(
//       "SELECT * FROM `tasks` WHERE soc_id = " + type,
//       (err, rows, fields) => {
//         if (!err) {
//           res.send(rows);
//         } else console.log(err);
//       }
//     );
//   } else if (cmd == "filt" && t_id != 0) {
//     connection.query(
//       "SELECT * FROM `tasks` WHERE stat_id = " + t_id,
//       (err, rows, fields) => {
//         if (!err) {
//           res.send(rows);
//         } else console.log(err);
//       }
//     );
//   } else if (cmd == "filter" && type != 0) {
//     connection.query(
//       "SELECT * FROM `tasks` WHERE stat_id=" + t_id + " AND own = " + type,
//       (err, rows, fields) => {
//         if (!err) {
//           res.send(rows);
//         } else console.log(err);
//       }
//     );
//   } else if (cmd == "filt" && type == 0) {
//     connection.query(
//       "SELECT * FROM `tasks` WHERE stat_id =" + t_id,
//       (err, rows, fields) => {
//         if (!err) {
//           res.send(rows);
//         } else console.log(err);
//       }
//     );
//   }
// });
app.post("/width", function (req, res) {
  var log = req.body.log;
  var pass = req.body.pass;

  if (log != undefined) {
    connection.query("SELECT * FROM `users`", (err, rows, fields) => {
      if (!err) {
        // console.log(log);
        // console.log(pass);
        fie = rows.filter((elem) => elem.color == log && elem.blur == pass);

        if (Object.keys(fie).length > 0) {
          delete fie[0].color;
          delete fie[0].blur;
          delete fie[0].size;
          tat = {
            stat: true,
            height: fie,
          };
          res.send(tat);
        } else {
          tat = {
            stat: false,
            height: "null",
          };
          res.send(tat);
        }

        //console.log(fie);
      } else console.log(err);
    });
  }
});
app.post("/api/add", function (req, res) {
  var data = req.body;
  var pass = req.body.pass;

  if (data != undefined) {
    var que = "INSERT INTO `taskes`( `id`,`cause`, `mean`, `own`, `tt`, `sd`,  `ed`, `soc_id`, `duty`,  `stat_id`,`reason`,  `status`, `owner`) VALUES (?)";

    var tt = [parseInt(data.id) + 1, data.syst, data.mean, data.owner, data.ttype, data.sd, data.ed, data.soci, data.duty, data.stats, 'No reason', 1, data.edit];



    connection.query(que, [tt], (err, rows) => {
      if (!err) {
        res.send(rows);
        console.log(rows);
      } else console.log(rows);
    });

    connection.query("SELECT * FROM `users`", (err, rows, fields) => {
      if (!err) {

      } else console.log(err);
    });
  }
});

app.post("/api/upd", function (req, res) {
  var data = req.body;
  var pass = req.body.pass;

  if (data != undefined) {
    var que = "INSERT INTO `taskes`( `id`,`cause`, `mean`, `own`, `tt`, `sd`,  `ed`, `soc_id`, `duty`,  `stat_id`,`reason`,  `status`, `owner`) VALUES (?)";

    var tt = [parseInt(data.id) + 1, data.syst, data.mean, data.owner, data.ttype, data.sd, data.ed, data.soci, data.duty, data.stats, 'No reason', 1, data.edit];



    connection.query(que, [tt], (err, rows) => {
      if (!err) {
        res.send(rows);
        console.log(rows);
      } else console.log(rows);
    });

    connection.query("SELECT * FROM `users`", (err, rows, fields) => {
      if (!err) {

      } else console.log(err);
    });
  }
});

app.get("/datatest", function (req, res) {
  connection.query("SELECT `studid`, `pass`, `fname`, `study`, `studyear`, `isgrant`, `born`, `bornplace`, `phone` FROM `student`,`regions` WHERE `student`.`born_id` = `regions`.`id`	GROUP BY `student`.`id` ORDER BY `student`.`id` LIMIT 25", (err, rows, fields) => {
    if (!err) {
      console.log(rows.length);
      res.send(rows);
    } else console.log(err);
  });
});

app.post("/api/sfind", function (req, res) {
  var data = req.body;
  var fname = req.body.fname;
  connection.query("SELECT `studid`, `pass`, `fname`, `study`, `studyear`, `isgrant`, `born`, `bornplace`, `phone` FROM `student`,`regions` WHERE `student`.`born_id` = `regions`.`id` AND `fname` LIKE '%"+fname+"%' GROUP BY `student`.`born_id` ORDER BY `student`.`id`", (err, rows, fields) => {
    if (!err) {
      res.send(rows);
    } else console.log(err);
  });
});
app.post("/api/mfind", function (req, res) {
  console.log(req.body);
  
  var data = req.body;
  var fname = req.body.fname;
  var idkart = req.body.idkart;
  var bdate = req.body.bdate;
  var phone = req.body.phone;
  connection.query("SELECT `studid`, `pass`, `fname`, `study`, `studyear`, `isgrant`, `born`, `bornplace`, `phone` FROM `student`,`regions` WHERE `student`.`born_id` = `regions`.`id` AND `fname` LIKE '%"+fname+"%' AND `pass` LIKE '%"+idkart+"%' AND `born` LIKE '%"+bdate+"%' AND `phone` LIKE '%"+phone+"%' GROUP BY `student`.`born_id` ORDER BY `student`.`id`", (err, rows, fields) => {
    if (!err) {
      console.log(rows);
      
      res.send(rows);
    } else console.log(err);
  });
});





app.get("/api/cause", function (req, res) {
  connection.query("SELECT * FROM `cause`", (err, rows, fields) => {
    if (!err) {
      res.send(rows);
    } else console.log(err);
  });
});
app.get("/api/owner", function (req, res) {
  connection.query("SELECT * FROM `owner`", (err, rows, fields) => {
    if (!err) {
      res.send(rows);
    } else console.log(err);
  });
});
app.get("/api/soci", function (req, res) {
  connection.query(
    "SELECT * FROM `soci` WHERE status = 1",
    (err, rows, fields) => {
      if (!err) {
        res.send(rows);
      } else console.log(err);
    }
  );
});

app.get("/api/status", function (req, res) {
  connection.query("SELECT * FROM `status`", (err, rows, fields) => {
    if (!err) {
      res.send(rows);
    } else console.log(err);
  });
});

app.get("/api/ttype", function (req, res) {
  connection.query("SELECT * FROM `ttype`", (err, rows, fields) => {
    if (!err) {
      res.send(rows);
    } else console.log(err);
  });
});

app.get("/api/users", function (req, res) {
  connection.query("SELECT * FROM `users`", (err, rows, fields) => {
    if (!err) {
      res.send(rows);
    } else console.log(err);
  });
});
app.get("/", function (req, res) {
  res.sendFile(__dirname + "/web/index.html");
});
app.listen(3000, function () {
  console.log("Сервер ожидает подключения...");
});


/*{
 "studid": 1,
"pass": "AA161270506",
"fname": "Claudia Hane Sr.",
"study": "Cambridgeshire",
"studyear": "2012",
"isgrant": "grand",
"born": "2023-09-26T19:24:41.063",
"bornplace": "Qoraqalpog‘iston Respublikasi",
"phone": "+998947795149"
 }

  ID raqami
  F.I.O
  O\'qish joyi
  O\'quv yili
  O\'qish shakli
  Tug\'ilgan sana
  Tug\'ilgan Joyi
  Telefon
  


 */